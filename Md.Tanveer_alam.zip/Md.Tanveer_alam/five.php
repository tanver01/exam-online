<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Online Quiz - Quiz List</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php require 'link.php'; ?>
</head>
<body>
<?php
include("header.php");
include("database.php");
echo "<h2 class=head1> Level 2 </h2>";

echo '<table width="28%"  border="0" align="center">
  
<h1> dfsgdfg</h1>

</table>';


?>
</body>
</html>
