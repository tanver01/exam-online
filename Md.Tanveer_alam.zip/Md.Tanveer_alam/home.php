<?php
session_start();
?>
<!DOCTYPE HTML >
<html>
<head>
<title>Welcome to Online Exam</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php ?>
<style type="text/css">
footer{
  margin-top: 30px;
  background-color:#337ab7;
  color: white;
  margin-bottom: 5px;
  text-align: center;
  padding: 8px;
  border-radius: 5px

}

</style>
</head>

<body>
<?php
 require 'link.php';
include("header3.php");
include("database.php");
extract($_POST);

if(isset($submit))
{
  $rs=mysql_query("select * from mst_user where login='$loginid' and pass='$pass'");
  if(mysql_num_rows($rs)<1)
  {
    $found="N";
  }
  else
  {
    $_SESSION[login]=$loginid;
  }
}
if (isset($_SESSION[login]))
{
echo "<h1 align=center>Wel come to Online Exam</h1>";
    echo '<table width="28%"  border="24" align="center">
  <tr>

    <td width="93%" valign="center" bordercolor="#0000FF"> <a href="sublist.php" class="style4">Subject for Quiz </a></td>
  </tr>

</table>';
   
    exit;
    

}
?>      
    <div class="container">
        <div class="col-md-4">
        </div>
        <div class="col-md-4">  
            <div class="login-panel panel panel-success">  
                <div class="panel-heading">  
                    <h2 class="panel-title">Login ID</h2>  
                </div>  
              <div class="panel-body"> 
                <form name="form1" method="post" action=""> 
                <fieldset>  
                <div class="form-group"> 
                  <tr>
                    <td>User Name</td>
                    <td><input class="form-control" name="loginid" type="text" id="loginid2"></td>
                  </tr>
               </div>
         <div class="form-group"> 
            <tr>
              <td>Password</td>
              <td><input class="form-control"  name="pass" type="password" id="pass2"></td>
            </tr>
        </div>
        <tr>
          <td colspan="2"><span class="errors">
            <?php
      if(isset($found))
      {
        echo "Invalid Username or Password";
      }
      ?>
          </span></td>
          </tr>
          <tr>
           <td colspan=2 align=center class="errors">
            <input class="btn btn-lg btn-success btn-block" name="submit" type="submit" id="submit" value="Login"></td>
          </tr>
            <tr>
              <td colspan="2" bgcolor="#CC3300"><div align="center"><span class="style4">New User ? <a href="signup.php">Signup Free</a></span></div></td>
            </tr>  
          </form>
        </div>
      

      <img src="images/connected_data_big.jpg" height="100px" width='100%'>
    </div>
    </div>
    <div class="col-md-4"> 
    </div>
   
    </div>     
    <div class="container">
    <footer>    
      <a href="#" target="_blank"><img src="image/glyphicons-social-3-google-plus.png" alt="Google+ Logo" class="social-icon"></a>
      <a href="https://www.facebook.com/tanveer701018" target="_blank"><img src="image/glyphicons-social-31-facebook.png" alt="Facebook Logo" class="social-icon"></a>
      <a href="#" target="_blank"><img src="image/glyphicons-social-23-youtube.png" alt="You tube" class="social-icon"></a>
      <a href="#" target="_blank"><img src="image/glyphicons-social-32-twitter.png" alt="Instagram Logo" class="social-icon"></a></br>
      <span id="copy">&copy;2018 Md. Tanveer Alam Developed this site</span> 
    </footer>
 </div> 
</body>
</html>
