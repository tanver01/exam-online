<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Welcome to quize-quick-quick</title>
<?php 
require 'link.php';
 ?>
<style type="text/css">
footer{
  margin-top: 40px;
  background-color:#337ab7;
  color: white;
  margin-bottom: 5px;
  text-align: center;
  padding: 8px;
  border-radius: 5px

}
</style>
</head>
<body>
</br>
 <div class="container">
    <nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
              </button>
        </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home</a></li>
          <li><a href="home.php">Start Quize</a></li>
          <li><a href="quize.php">Our Work</a></li>
          <li><a href="contact.php">Contact Us</a></li>
          <!-- <li><a href="home.php">Sign In</a></li> -->
          <li><a href="signup.php">Registration</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
      <li><a href="admin"><span class="glyphicon glyphicon-log-in"></span> Admin Login</a></li>
      </ul>
    </div>
  </nav>
</div>
<div class="container">
  <div class="col-sm-4">
<img src="images/more.jpg" height="100%" width="100%">
<div align="justify"><font color="black" size="5" background-color="green" font-family="SutonnyMJ"><p>
LICT project এর মাধ্যমে আমরা যা কিছু শিক্ষা গ্রহন করেছি, তা আমরা সম্পূর্ণরূপে প্রকাশ করেছি। এবং তা প্রয়োগ করে এই project তৈরি করেছি। ধন্যবানদ জানাচ্ছি BCC  কে এবং আমাদের শিক্ষককে  </p>
    </font></div></div>
    
<div class="col-sm-4">
<img src="images/temporary1.jpg" width="100%">
<div align="justify">

</div>
</div>
<div class="col-sm-4">
  <div align="justify">
    <strong><font color="black" size="3" background-color="green" font-family="SutonnyMJ"><p>
  <font color="red"> Admin user name and Password</font>
    <ol>
      <li>user: tanveer</li>
      <li>password : tanveer</li>
   
    </ol>
    <font color="red">User name and password</font>
    <ol>
      <li>User : tanveer</li> <li>Password : tanveer</li>
 
    </ol>
    <font color="red">Name: Md. Tanveer Alam</font></br>
        <font color="red">Graduate ID : G044427</font></br>
        <font color="red">Batch Name : TOP000505</font></br>
        <font color="red">tanveralam701018@gmail.com</font></br>
        
    <font color="black">Mobile: 01722820525<font>
    </p>
    </font>
  </strong>
  </div>
</div>
</div>

<div class="container">
    <footer>    
      <a href="#" target="_blank"><img src="image/glyphicons-social-3-google-plus.png" alt="Google+ Logo" class="social-icon"></a>
      <a href="https://www.facebook.com/tanveer701018" target="_blank"><img src="image/glyphicons-social-31-facebook.png" alt="Facebook Logo" class="social-icon"></a>
      <a href="#" target="_blank"><img src="image/glyphicons-social-23-youtube.png" alt="You tube" class="social-icon"></a>
      <a href="#" target="_blank"><img src="image/glyphicons-social-32-twitter.png" alt="Instagram Logo" class="social-icon"></a></br>
      <span id="copy">&copy;2018 Md. Tanveer Alam Developed this site</span> 
    </footer>
 </div>
</body>
</html>