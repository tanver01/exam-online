<?php
session_start();
require("../database.php");
include("header.php");
error_reporting(1);
?>
<?php require 'link.php'; ?>
<?php 

extract($_POST);

echo "<BR>";
if (!isset($_SESSION['alogin']))
{
	echo "<br><h2><div  class=head1>You are not Logged On Please Login to Access this Page</div></h2>";
	echo "<a href=index.php><h3 align=center>Click Here for Login</h3></a>";
	exit();
}
echo "<BR><h3 class=head1>Subject Add </h3>";

echo "<table width=100%>";
echo "<tr><td align=center></table>";
if($submit=='submit' || strlen($subname)>0 )
{
$rs=mysql_query("select * from mst_subject where sub_name='$subname'");
if (mysql_num_rows($rs)>0)
{
	echo "<br><br><br><div class=head1>Subject is Already Exists</div>";
	exit;
}
mysql_query("insert into mst_subject(sub_name) values ('$subname')",$cn) or die(mysql_error());
echo "<p align=center>Subject  <b> \"$subname \"</b> Added Successfully.</p>";
$submit="";
}
?>
<SCRIPT LANGUAGE="JavaScript">
function check() {
mt=document.form1.subname.value;
if (mt.length<1) {
alert("Please Enter Subject Name");
document.form1.subname.focus();
return false;
}
return true;
}
</script>



<title>Add Subject</title>
<div class="row">  
  <div class="col-md-4 col-md-offset-4">  
    <div class="login-panel panel panel-success">
      <div class="panel-body"> 
        <form name="form1" method="post" onSubmit="return check();">
         <fieldset>  
             <div class="form-group"> 
                <tr>
                <td>Enter Subject Name </td>
                <td><input class="form-control" name="subname" placeholder="enter language name" type="text" id="subname"></td>
                <tr>
              </div>
          <tr>
            <td><input class="btn btn-lg btn-success btn-block" type="submit" name="submit" value="Add" ></td>
          </tr>
        </fieldset> 
        </form>
      </div>
    </div>
  </div>
</div>
</div>
<p>&nbsp; </p>