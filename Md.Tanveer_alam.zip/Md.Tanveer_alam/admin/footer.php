</br></br><footer> <!-- footer -->
			
			<a href="#" target="_blank"><img src="img/google-wrap.png" alt="Google+ Logo" class="social-icon"></a>
			<a href="#" target="_blank"><img src="img/facebook-wrap.svg" alt="Facebook Logo" class="social-icon"></a>
			<a href="#" target="_blank"><img src="img/instagram-wrap.png" alt="Instagram Logo" class="social-icon"></a>
			<span id="copy">&copy;2018 Lions School and College. Developed this site  <a href="https://www.facebook.com/tanveer701018" target="_blank">Md.Tanveer Alam</a></span> 
		</footer> <!-- /footer -->

	</div> <!-- /main-container -->

</body>
</html>