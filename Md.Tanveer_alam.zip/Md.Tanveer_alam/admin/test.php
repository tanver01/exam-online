<!DOCTYPE HTML>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php require 'link.php'; ?>
</head>

<body>
<?php
echo date("d/m/Y")
?>
</body>
</html>
