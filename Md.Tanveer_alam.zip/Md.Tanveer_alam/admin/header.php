
</br>
 <div class="container">
    <nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
              </button>
          <!-- <a class="navbar-brand" href="#">Lions School And College</a> -->
        </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="../index.php">Home</a></li> 
        <li><a href="subadd.php">Subject Add</a></li> 
        <li><a href="questionadd.php">Qustion Add</a></li> 
        <li><a href="testadd.php">Test Add</a></li> 
      </ul>
      <ul class="nav navbar-nav navbar-right">
      <li><a href="../signout.php"><span class="glyphicon glyphicon-log-in"></span> log out</a></li>
      </ul>
    </div>
  </nav>
</div>
  <table width="100%">
  <tr>
    <td aling=right>
	<?php
	if(isset($_SESSION['alogin']))
	{
	
	 }
	 else
	 {
	 	echo "&nbsp;";
	 }
	?>
	</td>
  </tr>
</table>
