<?php
session_start()
?>

<!DOCTYPE HTML >
<html>
<head>
<title>Administrative Login - Online Exam</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php require 'link.php'; ?>
</head>

<body>
<h1 align="center">Adminstrative Login </h1>
<div class="row">  
        <div class="col-md-4 col-md-offset-4">  
            <div class="login-panel panel panel-success">  
                <div class="panel-heading">  
                    <h2 class="panel-title">Login ID</h2>  
                </div>  
            <div class="panel-body"> 
            <form name="form1" method="post" action="login.php">
               <fieldset>  
                <div class="form-group"> 
                  <tr>
                    <td ><img src="login.jpg" width="131" height="100" float="center"></td>
                  </tr>
                </div>
                <div class="form-group"> 
                  <tr>
                    <td>Login ID </td>
                    <td ><input class="form-control" name="loginid" type="text" id="loginid"></td>
                  </tr>
                </div>
                <div class="form-group"> 
                  <tr>
                    <td>Password</td>
                    <td><input class="form-control" name="pass" type="password" id="pass"></td>
                  </tr>
                </div>
              
                  <tr>
                    <td><input class="btn btn-lg btn-success btn-block" name="submit" type="submit" id="submit" value="Login"></td>
              </fieldset>  
            </form>
          </div>
        </div>
      </div>
    </div>
<p>&nbsp; </p>
</body>
</html>
