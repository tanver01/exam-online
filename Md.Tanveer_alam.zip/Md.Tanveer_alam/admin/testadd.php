<?php
session_start();
error_reporting(0);
if (!isset($_SESSION['alogin']))
{
	echo "<br><h2>You are not Logged On Please Login to Access this Page</h2>";
	echo "<a href=home.php><h3 align=center>Click Here for Login</h3></a>";
	exit();
}
?>
<?php require 'link.php'; ?>
<?php
require("../database.php");

include("header.php");


echo "<br><h2><div  class=head1>Add Test</div></h2>";
if($_POST[submit]=='Save' || strlen($_POST['subid'])>0 )
{
extract($_POST);
mysql_query("insert into mst_test(sub_id,test_name,total_que) values ('$subid','$testname','$totque')",$cn) or die(mysql_error());
echo "<p align=center>Test <b>\"$testname\"</b> Added Successfully.</p>";
unset($_POST);
}
?>
<SCRIPT LANGUAGE="JavaScript">
function check() {
mt=document.form1.testname.value;
if (mt.length<1) {
alert("Please Enter Test Name");
document.form1.testname.focus();
return false;
}
tt=document.form1.totque.value;
if(tt.length<1) {
alert("Please Enter Total Question");
document.form1.totque.value;
return false;
}
return true;
}
</script>
<div class="row">  
  <div class="col-md-4 col-md-offset-4">  
    <div class="login-panel panel panel-success">  
      <div class="panel-heading">  
        <h2 class="panel-title">Add Test</h2>  
          </div>  
            <div class="panel-body"> 
            <form name="form1" method="post" onSubmit="return check();">
  <fieldset>
    <div class="form-group">
    <tr>
      <td><strong>Enter Subject ID </strong></td>
      <td><select name="subid">
<?php
$rs=mysql_query("Select * from mst_subject order by  sub_name",$cn);
	  while($row=mysql_fetch_array($rs))
{
if($row[0]==$subid)
{
echo "<option value='$row[0]' selected>$row[1]</option>";
}
else
{
echo "<option value='$row[0]'>$row[1]</option>";
}
}
?>
      </select>
        
    <tr>
    </div>
     <div class="form-group"> 
      <tr>
        <td><strong> Enter Test Name </strong></td>
	      <td><input class="form-control" name="testname" type="text" id="testname"></td>
      </tr>
    </div>
    <div class="form-group"> 
      <tr>
        <td ><strong>Enter Total Question </strong></td>
        <td><input class="form-control" name="totque" type="text" id="totque"></td>
      </tr>
    </div>
    <tr>
      <td><input class="btn btn-lg btn-success btn-block" type="submit" name="submit" value="Add" ></td>
    </tr>
  </table>
</form>
<p>&nbsp; </p>
