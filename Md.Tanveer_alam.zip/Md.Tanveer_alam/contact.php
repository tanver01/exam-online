
<?php 
require 'validation.php';
 ?>
<?php 
require 'link.php';
require 'header2.php';
 ?>
<style type="text/css">
footer{
  margin-top: 480px;
  background-color:#337ab7;
  color: white;
  margin-bottom: 5px;
  text-align: center;
  padding: 8px;
  border-radius: 5px

}

</style>
 <div class="container"> <!-- main-container -->
  <div class="col-sm-4">
   <h2>Send Message</h2><br> 
  <form method="post" action="contact.php"> 
   <fieldset>  
    <div class="form-group"> 
    <tr>
    <td>Name :</td>
    <input class="form-control" type="text" name="name" value="">
    <span class="error"><?php echo $nameError;?></span>
    </tr>
    </div>        
    <div class="form-group"> 
    <tr>    
    <td>Email :</td>
    <input class="form-control" type="text" name="email" value="">
    <span class="error"><?php echo $emailError;?></span>
     </tr>
     </div>
   <div class="form-group"> 
    <tr>       
      <td>Message :</td>
      <textarea class="form-control" name="message" val=""></textarea>
      <span class="error"><?php echo $messageError;?></span>
    </tr>
   </div>
    <tr>        
    <input class="btn btn-lg btn-success btn-block" type="submit" name="submit" value="Send"></tr>
    <span class="success"><?php echo $successMessage;?></span>
  </fieldset>
    </form></div>
    
  <div class="col-sm-4"><br><br><br><br>
     <td width="51%"><div align="center"> 
                  <h2>Contact Information</h2>
                  <p>Kaya Mistry Para<br>
                    Mondir Road, Sadipur-5310<br>
                    Nilphamari, Bangladesh.</br>
                  Phone: +880-01722820525
                  </br> 
                  email: tanveralam570@@gmail.com</p>
                </div></td>
          <td width="27%">&nbsp;</td>
  </div> 

  <div class="col-sm-4">
<div class="mapouter"><div class="gmap_canvas"><a href="https://www.pureblack.de"></a><iframe width="350" height="450" id="gmap_canvas" src="https://maps.google.com/maps?q=saidpur, nilphamary, gaushia masjid&t=&z=11&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div><style>.mapouter{overflow:hidden;height:450px;width:350px;}.gmap_canvas {background:none!important;height:450px;width:350px;}</style></div> </div>
    
    <footer>    
      <a href="#" target="_blank"><img src="image/glyphicons-social-3-google-plus.png" alt="Google+ Logo" class="social-icon"></a>
      <a href="https://www.facebook.com/tanveer701018" target="_blank"><img src="image/glyphicons-social-31-facebook.png" alt="Facebook Logo" class="social-icon"></a>
      <a href="#" target="_blank"><img src="image/glyphicons-social-23-youtube.png" alt="You tube" class="social-icon"></a>
      <a href="#" target="_blank"><img src="image/glyphicons-social-32-twitter.png" alt="Instagram Logo" class="social-icon"></a></br>
      <span id="copy">&copy;2018 Md. Tanveer Alam Developed this site</span> 
    </footer>
 </div> 

