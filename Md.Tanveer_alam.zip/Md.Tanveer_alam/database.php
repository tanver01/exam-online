<?php
//all the variables defined here are accessible in all the files that include this one
("SET NAMES utf8");
$cn=mysql_connect("localhost","root","") or die("Could not Connect My Sql");
mysql_select_db("quiz",$cn)  or die("Could connect to Database");
('SET CHARACTER SET utf8');
("SET SESSION collection_connection ='utf8_general_ci'");
?>
 