<?php
session_start();
?>
<!DOCTYPE HTML >
<html>
<head>
<title>Online Quiz  - Result </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php require 'link.php'; ?>
<style type="text/css">
footer{
  margin-top: 350px;
  background-color:#337ab7;
  color: white;
  margin-bottom: 5px;
  text-align: center;
  padding: 8px;
  border-radius: 5px

}

</style>
</head>

<body> 
<?php
include("header1.php");
include("database.php");
extract($_SESSION);
$rs=mysql_query("select t.test_name,t.total_que,r.test_date,r.score from mst_test t, mst_result r where
t.test_id=r.test_id and r.login='$login'",$cn) or die(mysql_error());

echo "<h1 class=head1> Result </h1>";

if(mysql_num_rows($rs)<1)
{
	echo "<br><br><h1 class=head1> You have not given any quiz</h1>";
	exit;
}

echo "<table border=1 align=center><tr class=style2 align='center'><td width=300 >Test Name <td> Total<br> Question <td> Score";
while($row=mysql_fetch_row($rs))
{
echo "<tr class=style8 ><td >$row[0] <td align=center> $row[1] <td align=center> $row[3]";
}
echo "</table>";
?>
<div class="container">
    <footer>    
      <a href="#" target="_blank"><img src="image/glyphicons-social-3-google-plus.png" alt="Google+ Logo" class="social-icon"></a>
      <a href="https://www.facebook.com/tanveer701018" target="_blank"><img src="image/glyphicons-social-31-facebook.png" alt="Facebook Logo" class="social-icon"></a>
      <a href="#" target="_blank"><img src="image/glyphicons-social-23-youtube.png" alt="You tube" class="social-icon"></a>
      <a href="#" target="_blank"><img src="image/glyphicons-social-32-twitter.png" alt="Instagram Logo" class="social-icon"></a></br>
      <span id="copy">&copy;2018 Md. Tanveer Alam Developed this site</span> 
    </footer>
 </div> 
</body>
</html>
